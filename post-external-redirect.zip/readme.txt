=== Post External Redirect ===
Contributors: asifkhan
Tags: redirect, external link, page redirect, post redirect
Requires at least: 5.5
Tested up to: 6.5
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Redirect posts or pages to external URLs with ease.

== Description ==
Post External Redirect allows you to redirect any post or page to an external URL.
Ideal for press coverage, featured articles, or outbound content.

== Installation ==
1. Upload the plugin folder to `/wp-content/plugins/`
2. Activate the plugin
3. Edit any post or page
4. Add an external URL in the “External Redirect” box

== Frequently Asked Questions ==
= Does this affect SEO? =
Redirects use a temporary (302) redirect by default.

= Can I use it on pages? =
Yes, both posts and pages are supported.

== Changelog ==
= 1.0.0 =
* Initial release
