<?php
/*
Plugin Name: Post External Redirect
Plugin URI: https://example.com/post-external-redirect
Description: Redirect posts or pages to an external URL instead of opening the single post page.
Version: 1.0.0
Requires at least: 5.5
Tested up to: 6.5
Requires PHP: 7.4
Author: Asif Khan
Author URI: https://example.com
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: post-external-redirect
Domain Path: /languages
*/

if (!defined('ABSPATH')) exit;

/**
 * Add meta box
 */
function per_add_meta_box() {
    add_meta_box(
        'per_external_link',
        __('External Redirect', 'post-external-redirect'),
        'per_meta_box_callback',
        ['post', 'page'],
        'side'
    );
}
add_action('add_meta_boxes', 'per_add_meta_box');

/**
 * Meta box HTML
 */
function per_meta_box_callback($post) {
    if (!current_user_can('edit_post', $post->ID)) return;

    $url     = get_post_meta($post->ID, '_per_external_url', true);
    $new_tab = get_post_meta($post->ID, '_per_open_new_tab', true);

    wp_nonce_field('per_save_meta', 'per_nonce');
    ?>
    <p>
        <label for="per_external_url"><strong><?php _e('External URL', 'post-external-redirect'); ?></strong></label>
        <input type="url" id="per_external_url" name="per_external_url"
               value="<?php echo esc_attr($url); ?>"
               style="width:100%;" placeholder="https://example.com">
    </p>

    <p>
        <label>
            <input type="checkbox" name="per_open_new_tab" value="1" <?php checked($new_tab, 1); ?>>
            <?php _e('Open link in new tab', 'post-external-redirect'); ?>
        </label>
    </p>
    <?php
}

/**
 * Save meta
 */
function per_save_meta($post_id) {

    if (!isset($_POST['per_nonce']) ||
        !wp_verify_nonce($_POST['per_nonce'], 'per_save_meta')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;

    if (isset($_POST['per_external_url'])) {
        update_post_meta(
            $post_id,
            '_per_external_url',
            esc_url_raw($_POST['per_external_url'])
        );
    }

    update_post_meta(
        $post_id,
        '_per_open_new_tab',
        isset($_POST['per_open_new_tab']) ? 1 : 0
    );
}
add_action('save_post', 'per_save_meta');

/**
 * Safe redirect
 */
function per_redirect_external() {
    if (!is_singular()) return;

    $post_id = get_queried_object_id();
    if (!$post_id) return;

    $url = get_post_meta($post_id, '_per_external_url', true);

    if ($url) {
        wp_safe_redirect($url, 302);
        exit;
    }
}
add_action('template_redirect', 'per_redirect_external');

/**
 * Change permalink
 */
function per_change_permalink($link, $post) {
    $url = get_post_meta($post->ID, '_per_external_url', true);
    return $url ? esc_url($url) : $link;
}
add_filter('post_link', 'per_change_permalink', 10, 2);
add_filter('page_link', 'per_change_permalink', 10, 2);
